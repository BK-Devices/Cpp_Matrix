#include"header.h"

void Matrix :: addMatrix(Matrix &MatB, Matrix &Res)
{
    if(r!=MatB.r || c!=MatB.c)
    {
        cout<<"For addition order of matrix must be same"<<endl;
        result=false;
        return;
    }

    Res.deallocate();
    Res.allocate(r, c);
    
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            Res.mat[i][j]=mat[i][j]+MatB.mat[i][j];
        }
    }
}


void Matrix :: subMatrix(Matrix &MatB, Matrix &Res)
{
    if(r!=MatB.r || c!=MatB.c)
    {
        cout<<"For addition order of matrix must be same"<<endl;
        result=false;
        return;
    }

    Res.deallocate();
    Res.allocate(r, c);
    
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            Res.mat[i][j]=mat[i][j]-MatB.mat[i][j];
        }
    }
}

