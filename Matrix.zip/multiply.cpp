#include"header.h"

void Matrix :: multiMatrix(Matrix &MatB, Matrix &Res)
{
    int k=0;
    if(c!=MatB.r)
    {
        cout<<"For multiplication columns of 1st and Rows of 2nd must be same"<<endl;
        result=false;
        return;
    }

    Res.deallocate();
    Res.allocate(r, MatB.c);
    
    for(i=0; i<r; i++)
    {
        for(j=0; j<MatB.c; j++)
        {
            Res.mat[i][j]=0;
            for(k=0; k<c; k++){
                Res.mat[i][j]+=(mat[i][k]*MatB.mat[k][j]);
            }
        }
    }
}


void Matrix :: scalarMulti(Matrix &Res)
{
    int sc=0;
    cout<<"Enter scalar : ";
    cin>>sc;

    Res.deallocate();
    Res.allocate(r, c);

    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            Res.mat[i][j]=mat[i][j]*sc;
        }
    }
}

