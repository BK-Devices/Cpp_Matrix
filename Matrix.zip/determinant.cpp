#include"header.h"

int Matrix :: determinant()
{
    int det=0;

    if(r!=c)
    {
        cout<<"Determinant of square matrix is only possible";
        result=false;
        return det;
    }

    if(r==1)
    {
        return mat[0][0];
    }
    else if(r==2)
    {
        return ((mat[0][0]*mat[1][1]) - (mat[0][1]*mat[1][0]));
    }
    else
    {
        int k=0, l=0, m=0;
        Matrix Obj;

        Obj.allocate(r-1, r-1);

        for(m=0; m<c; m++)
        {
            l=k=0;
            for(i=0; i<r; i++)
            {
                for(j=0; j<c; j++)
                {
                    if(i==0 || j==m) continue;

                    Obj.mat[k][l]=mat[i][j];

                    l++;
                    if(l==r-1)
                    {
                        k++;
                        l=0;
                    }
                }
            }

            det += (m%2?-1:1) * mat[0][m] * Obj.determinant();
        }

        return det;
    }
}

