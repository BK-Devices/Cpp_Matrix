#include"header.h"

void Matrix :: printMatrix(string str)
{
    if(mat!=nullptr)
    {
        for(i=0; i<r; i++)
        {
            if(i==(r/2)-!(r%2)) cout<<str;
            else cout<<string(str.length(), ' ');
            
            cout<<"[";
            for(j=0; j<c; j++)
            {
                printf("%4d ", mat[i][j]);
            }
            cout<<"]"<<endl;
        }
        cout<<endl;
    }
}


void Matrix :: transMatrix(Matrix &Res)
{
    Res.deallocate();
    Res.allocate(c, r);

    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            Res.mat[j][i]=mat[i][j];
        }
    }
}

