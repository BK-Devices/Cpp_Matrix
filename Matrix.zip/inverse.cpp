#include"header.h"

int Matrix :: inverseMatrix(Matrix &Res)
{
    int det=0;

    if(r!=c)
    {
        cout<<"inverse of square matrix is only possible"<<endl;
        result=false;
        return det;
    }

    det = determinant();
    if(det==0)
    {
        cout<<"inverse of a matrix is not exists"<<endl;
        result=false;
        return det;
    }

    if(r==1)
    {
        Res.deallocate();
        Res.allocate(1, 1);
        Res.mat[0][0]=1;
    }
    else if(r==2)
    {
        Res.deallocate();
        Res.allocate(2, 2);
        Res.mat[0][0] = mat[1][1];
        Res.mat[1][1] = mat[0][0];
        Res.mat[0][1] = -mat[0][1];
        Res.mat[1][0] = -mat[1][0];
    }
    else
    {
        int k, l, m, n;
        Matrix Obj;
        Obj.allocate(r, r);

        Res.deallocate();
        Res.allocate(r-1, r-1);

        for(i=0; i<r; i++)
        {
            for(j=0; j<c; j++)
            {
                m=n=0;
                for(k=0; k<r; k++)
                {
                    for(l=0; l<c; l++)
                    {
                        if(k==i || l==j) continue;
                        Res.mat[m][n]=mat[k][l];
                        n++;
                        if(n==r-1)
                        {
                            n=0;
                            m++;
                        }
                    }
                }

                Obj.mat[i][j] = Res.determinant() * ((i+j)%2?-1:1);
            }
        }

        Obj.transMatrix(Res);
    }

    return det;
}

