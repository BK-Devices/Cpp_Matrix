#include"header.h"

void Matrix :: deallocate()
{
    // Deallocating previous allocated memory
    if(mat!=nullptr)
    {
        for(i=0; i<r; i++) delete mat[i];
        delete mat;
    }
}


void Matrix :: allocate(int r, int c)
{
    this->r=r;
    this->c=c;
    // Allocating memory
    mat=new int*[r];
    for(i=0; i<r; i++) mat[i]=new int[c];
}

