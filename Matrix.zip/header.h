#include<iostream>
using namespace std;

#ifdef _WIN32
#define clrscr() system("cls");
#elif __linux__
#define clrscr() system("clear");
#endif

class Matrix;

