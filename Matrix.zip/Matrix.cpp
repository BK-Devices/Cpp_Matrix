#include"header.h"

bool result=true; 

class Matrix
{
    int r, c, i, j;
    int **mat;

    void deallocate();
    void allocate(int r, int c);

    public:
    Matrix()
    {
        i=j=0;
        r=c=0;
        mat=nullptr;
    }

    ~Matrix()
    {
        deallocate();
    }

    void defineMatrix();
    void defineMatrix(Matrix &Res);
    void printMatrix(string str);
    void addMatrix(Matrix &MatB, Matrix &Res);
    void subMatrix(Matrix &MatB, Matrix &Res);
    void multiMatrix(Matrix &MatB, Matrix &Res);
    void scalarMulti(Matrix &Res);
    void transMatrix(Matrix &Res);
    int determinant();
    int inverseMatrix(Matrix &Res);
};

#include"addSub.cpp"
#include"defineMatrix.cpp"
#include"determinant.cpp"
#include"inverse.cpp"
#include"memory.cpp"
#include"multiply.cpp"
#include"other.cpp"

int main()
{
    int ch=0;
    Matrix MatA, MatB, Res;

    // Define Matrix
    clrscr();
    cout<<"Define Matrix A - "<<endl;
    MatA.defineMatrix();
    clrscr();
    cout<<"Define Matrix B - "<<endl;
    MatB.defineMatrix();

    while(1)
    {
        cout<<"\n\n1 - Define Matrix"<<endl;
        cout<<"2 - Addition"<<endl;
        cout<<"3 - Substraction"<<endl;
        cout<<"4 - Multiplication"<<endl;
        cout<<"5 - Scalar Multiplication"<<endl;
        cout<<"6 - Determinant"<<endl;
        cout<<"7 - Transpose"<<endl;
        cout<<"8 - Inverse"<<endl;
        cout<<"9 - Print matrices"<<endl;
        cout<<"10 - Exit"<<endl;

        cout<<"Enter your choice : ";
        cin>>ch;

        clrscr();
        switch(ch)
        {
            // Defining Matrix
            case 1: cout<<"1 - MatA  &  2 - MatB"<<endl;
                    cout<<"3 - MatA=Res  &  4 - MatB=Res : ";
                    cin>>ch;
                    if(ch==1) MatA.defineMatrix();
                    else if(ch==2) MatB.defineMatrix();
                    else if(ch==3) MatA.defineMatrix(Res);
                    else MatB.defineMatrix(Res);
                    break;

            // Adding matrix
            case 2: MatA.addMatrix(MatB, Res);
                    if(result) goto PRINT;
                    result=true;
                    break;

            // Substracting matrix
            case 3: cout<<"1 - MatA-MatB  &  2 - MatB-MatA : ";
                    cin>>ch;
                    if(ch==1) MatA.subMatrix(MatB, Res);
                    else MatB.subMatrix(MatA, Res);
                    if(result) goto PRINT;
                    result=true;
                    break;

            // Multiplication of two matrix
            case 4: cout<<"1 - MatA*MatB  &  2 - MatB*MatA : ";
                    cin>>ch;
                    if(ch==1) MatA.multiMatrix(MatB, Res);
                    else MatB.multiMatrix(MatA, Res);
                    if(result) goto PRINT;
                    result=true;
                    break;
            
            // Multiplication of matrix with scalar
            case 5: cout<<"1 - (MatA * sc)  &  2 - (MatB * sc) : ";
                    cin>>ch;
                    if(ch==1) MatA.scalarMulti(Res);
                    else MatB.scalarMulti(Res);
                    goto PRINT;
                    break;
            
            // Finding determinant
            case 6: cout<<"1 - |MatA|  &  2 - |MatB| : ";
                    cin>>ch;
                    if(ch==1)
                    {
                        ch=MatA.determinant();
                        if(result) cout<<"|MatA| = "<<ch<<endl;
                        result=true;
                    }
                    else
                    {
                        ch=MatB.determinant();
                        if(result) cout<<"|MatB| = "<<ch<<endl;
                        result=true;
                    }
                    break;
            
            // Finding Transpose
            case 7: cout<<"1 - T(MatA)  &  2 - T(MatB) : ";
                    cin>>ch;
                    if(ch==1) MatA.transMatrix(Res);
                    else MatB.transMatrix(Res);
                    goto PRINT;
                    break;
            
            // Finding Inverse
            case 8: cout<<"1 - Inv(MatA)  &  2 - Inv(MatB) : ";
                    cin>>ch;
                    if(ch==1)
                    {
                        ch=MatA.inverseMatrix(Res);
                        if(result) Res.printMatrix("Inv(MatA) = 1/" + to_string(ch) + " * ");
                        result=true;
                    }
                    else
                    {
                        ch=MatB.inverseMatrix(Res);
                        if(result) Res.printMatrix("Inv(MatB) = 1/" + to_string(ch) + " * ");
                        result=true;
                    }
                    break;

            case 9: PRINT:
                    MatA.printMatrix("MatA = ");
                    MatB.printMatrix("MatB = ");
                    Res.printMatrix("Res = ");
                    break;

            case 10: cout<<"Thank you!"<<endl;
                     return 0;
            default: cout<<"Wrong choice"<<endl;
        }
    }

    return 0;
}

