#include"header.h"

void Matrix :: defineMatrix()
{
    deallocate(); // Deallocating previous allocated memory
    
    // Taking new size of matrix
    cout<<"Enter the rows & cols : ";
    cin>>r>>c;
    // Default 1 for wrong input
    if(r<1) r=1;
    if(c<1) c=1;

    allocate(r, c); // Allocating memory

    // Taking input
    for(i=0; i<r; i++)
    {
        for(j=0; j<c; j++)
        {
            cout<<"Enter M"<<i+1<<j+1<<" element : ";
            cin>>mat[i][j];
        }
    }
}


void Matrix :: defineMatrix(Matrix &Res)
{
    deallocate(); // Deallocating previous allocated memory
    
    // Copying data from result
    mat=Res.mat;
    r=Res.r;
    c=Res.c;

    Res.mat=nullptr;
}

